package pobj.tme6;

import javafx.scene.paint.Color;

public interface IColorTurtle extends ITurtle {
	
	public void setColor(Color color);

}
