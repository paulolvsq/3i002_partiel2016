package pobj.tme6;

import java.awt.Color;

public interface IColorTurtle extends ITurtle {
	
	public void setColor(Color color);

}
