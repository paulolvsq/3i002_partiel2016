package pobj.tme6;

public class Substitution {
	
	public static ICommand substitute(ICommand org, ICommand subst) {
		
	}

}
